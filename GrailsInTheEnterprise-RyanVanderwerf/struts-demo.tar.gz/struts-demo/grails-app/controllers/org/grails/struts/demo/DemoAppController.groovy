package org.grails.struts.demo

class DemoAppController {

    def index() { }

    def listPerson() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [personInstanceList: Person.list(params), personInstanceTotal: Person.count()]
    }

}
