package org.grails.struts.demo



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
@TestFor(PersonService)
class PersonServiceTests {

    void testSomething() {
        fail "Implement me"
    }
}
