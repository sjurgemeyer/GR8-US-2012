grails-struts1
==============

Grails Struts1 Plugin

This version of the plugin has been updated to work with Grails 2.0.4+


Ryan Vanderwerf
rvanderwerf@gmail.com
