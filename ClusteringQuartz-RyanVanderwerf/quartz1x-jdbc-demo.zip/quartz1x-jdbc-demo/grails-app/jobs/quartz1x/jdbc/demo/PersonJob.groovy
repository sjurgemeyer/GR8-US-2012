package quartz1x.jdbc.demo

import static org.apache.commons.lang.RandomStringUtils.*

class CreatePersonJob {

    static triggers = {
        simple repeatInterval: 5000l // execute job once in 5s seconds
    }

    def execute() {

        System.out.println("Creating new person")
        def person = new Person()
        String randomString = random(9, true, true)
        person.email = "${randomString}@${randomString}.com"
        person.firstName = randomString
        person.lastName = randomString
        person.phone = "5121221212"
        log.debug("saving new person")
        person.save(flush: true)

    }
}
