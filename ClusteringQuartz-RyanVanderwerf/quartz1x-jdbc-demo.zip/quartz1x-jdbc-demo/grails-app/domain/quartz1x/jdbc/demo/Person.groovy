package quartz1x.jdbc.demo

class Person {

    String firstName
    String lastName

    String email
    String phone
    static constraints = {
    }
}
