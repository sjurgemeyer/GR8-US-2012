package quartz1x.tc.demo

class Person {

    static constraints = {
    }
    String email
    String firstName
    String lastName
}
